/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	CKEDITOR.config.height = 150;
  	CKEDITOR.config.width = 'auto';
	config.language = 'vi';
	config.uiColor = '#f5f5f5';
};
