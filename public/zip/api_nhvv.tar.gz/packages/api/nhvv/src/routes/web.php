<?php
$apiPrefix = config('site.api_prefix');
Route::group(array('prefix' => $apiPrefix), function() {
    Route::get('version', 'SettingController@version')->name('api.nhvv.setting.version');
    Route::get('setting', 'SettingController@setting')->name('api.nhvv.setting.setting');

    Route::get('demo', 'SettingController@demo')->name('api.nhvv.setting.demo');

    Route::get('listMaterial', 'SettingController@listMaterial')->name('api.nhvv.setting.listMaterial');
    Route::get('listMaterialPackage', 'SettingController@listMaterialPackage')->name('api.nhvv.setting.listMaterialPackage');
    Route::get('listMaterialMarketTab', 'SettingController@listMaterialMarketTab')->name('api.nhvv.setting.listMaterialMarketTab');

    Route::get('listDecoration', 'SettingController@listDecoration')->name('api.nhvv.setting.listDecoration');
    Route::get('listDecorationgroup', 'SettingController@listDecorationgroup')->name('api.nhvv.setting.listDecorationgroup');
    Route::get('listDecorationTag', 'SettingController@listDecorationTag')->name('api.nhvv.setting.listDecorationTag');

    Route::get('listStaff', 'SettingController@listStaff')->name('api.nhvv.setting.listStaff');
    Route::get('listStaffPosition', 'SettingController@listStaffPosition')->name('api.nhvv.setting.listStaffPosition');

    Route::get('listBundle', 'SettingController@listBundle')->name('api.nhvv.setting.listBundle');
    Route::get('listFoodRecipe', 'SettingController@listFoodRecipe')->name('api.nhvv.setting.listFoodRecipe');
    Route::get('listStorageTab', 'SettingController@listStorageTab')->name('api.nhvv.setting.listStorageTab');
    Route::get('listRecipeTab', 'SettingController@listRecipeTab')->name('api.nhvv.setting.listRecipeTab');
});