<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "subject" => [
    	"delete"=>[
        	"title" => "Xóa môn",
        	"body" => "Bạn có chắc muốn xóa môn này?"
    	]
    ]
];
