<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "classes" => [
    	"delete"=>[
        	"title" => "Xóa Lớp",
        	"body" => "Bạn có chắc muốn xóa lớp này?"
    	]
    ]
];
