<div class="c-related-courses">
    <h3 class="title">Các khóa học liên quan</h3>
    <ol class="list">
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
        <li class="item">
            <div class="img">
                <a href=""><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/c7.png" alt=""></a>
            </div>
            <div class="inner">
                <h4 class="title"><a href="">Khóa học bồi dưỡng học sinh giỏi lớp 2</a></h4>
                <div class="price"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/src/images/tag.png" alt=""> <span>1.000.000<small>đ</small></span></div>
            </div>
        </li>
    </ol>
</div> <!-- / related courses -->