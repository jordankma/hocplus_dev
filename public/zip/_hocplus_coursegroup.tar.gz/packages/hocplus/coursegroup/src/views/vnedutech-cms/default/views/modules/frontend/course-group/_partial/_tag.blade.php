<div class="c-tag">
    <div class="title">Môn học được quan tâm</div>
    <ul class="list">
        <li class="item"><a href="http://">môn toán</a></li>
        <li class="item"><a href="http://">môn văn</a></li>
        <li class="item"><a href="http://">môn địa lý</a></li>
        <li class="item"><a href="http://">môn sinh học</a></li>
        <li class="item"><a href="http://">môn vật lý</a></li>
    </ul>
</div> <!-- / tag -->