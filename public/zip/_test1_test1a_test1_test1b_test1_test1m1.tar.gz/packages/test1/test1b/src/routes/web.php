<?php

$adminPrefix = config('site.admin_prefix');
Route::group(array('prefix' => $adminPrefix), function() {
    Route::get('test1/test1b/index/data', 'IndexController@data')->name('test1.test1b.index.data');
    Route::get('test1/test1b/index/manage', 'IndexController@manage')->name('test1.test1b.index.manage');
    Route::get('test1/test1b/index/create', 'IndexController@create')->name('test1.test1b.index.create');
    Route::post('test1/test1b/index/add', 'IndexController@add')->name('test1.test1b.index.add');
    Route::get('test1/test1b/index/show', 'IndexController@show')->name('test1.test1b.index.show');
    Route::put('test1/test1b/index/update', 'IndexController@update')->name('test1.test1b.index.update');
    Route::get('test1/test1b/index/delete', 'IndexController@delete')->name('test1.test1b.index.delete');
    Route::get('test1/test1b/index/confirm-delete', 'IndexController@getModalDelete')->name('test1.test1b.index.confirm-delete');
});