<?php

return [
    "email_unique" => "Your email is already use.",
    "confirm_password_same" => "Confirm password not same.",
    "confirm_password_required" => "Confirm password is required.",
];
