<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "teacher" => [
    	"delete"=>[
        	"title" => "Xóa giáo viên",
        	"body" => "Bạn có chắc muốn xóa giáo viên này?"
    	]
    ]
];
