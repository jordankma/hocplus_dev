<?php

return [
    "add_new" => "Add new",
    "account" => "Account",
    "back" => "Back",
    "save" => "Save",
    "create" => "Create",
    "create_account" => "Create New Account",
    "change_password" => "Change Password",
    "close" => "Close",
    "close_icon" => "✖",
    "login" => "Login",
    "logout" => "Logout",
    "forgot_password" => "Forgot Password",
    "reset_password" => "Reset Password",
    "edit" => "Edit",
];
