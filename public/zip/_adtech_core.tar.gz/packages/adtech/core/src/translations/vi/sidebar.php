<?php

return [
    'dashboard' => 'Tổng quan'
];