<?php
/**
 * Created by PhpStorm.
 * User: Electric
 * Date: 9/8/2018
 * Time: 4:37 PM
 */
return [
    'recaptcha'=>'Form đăng ký không dành cho robot'
];
