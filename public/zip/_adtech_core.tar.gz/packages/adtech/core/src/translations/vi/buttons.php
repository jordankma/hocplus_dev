<?php

return [
    "add_new" => "Tạo mới",
    "account" => "Tài khoản",
    "search" => "Tìm kiếm",
    "back" => "Trở lại",
    "save" => "Lưu",
    "create" => "Tạo mới",
    "discard" => "Huỷ",
    "confirm" => "Xác nhận",
    "create_account" => "Tạo tài khoản",
    "change_password" => "Đổi mật khẩu",
    "close" => "Đóng",
    "close_icon" => "✖",
    "login" => "Đăng nhập",
    "logout" => "Đăng xuất",
    "forgot_password" => "Quên mật khẩu?",
    "reset_password" => "Tạo lại mật khẩu",
    "edit" => "Sửa",
    "create_package" => "Tạo package",
    "create_module" => "Tạo module",
    "update" => "Lưu"
];
