<?php

return [
    'cpc_today' => 'CPC trong ngày',
    'cpc_today' => 'CPC trong ngày',
];
