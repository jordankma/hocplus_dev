<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "member" => [
    	"delete"=>[
        	"title" => "Xóa tài khoản",
        	"body" => "Bạn có chắc muốn xóa tài khoản này?"
    	]
    ]
];
