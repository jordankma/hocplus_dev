<div class="c-left-why">
    <div class="item">
        <div class="icon"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/icon/icon-08.png" alt=""></div>
        <div class="content">
            <div class="title">4,500 bài giảng</div>
            <div class="text">Với rất nhiều phương pháp học tập</div>
        </div>
    </div>
    <div class="item">
        <div class="icon"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/icon/icon-09.png" alt=""></div>
        <div class="content">
            <div class="title">Được học với các GV hàng đầu</div>
            <div class="text">Tìm giảng viên phù hợp với bạn</div>
        </div>
    </div>
    <div class="item">
        <div class="icon"><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/icon/icon-10.png" alt=""></div>
        <div class="content">
            <div class="title">Truy cập trọn đời</div>
            <div class="text">
                Bạn có thể xem lại bất cứ khi nào muốn</div>
        </div>
    </div>
</div> <!-- / why -->