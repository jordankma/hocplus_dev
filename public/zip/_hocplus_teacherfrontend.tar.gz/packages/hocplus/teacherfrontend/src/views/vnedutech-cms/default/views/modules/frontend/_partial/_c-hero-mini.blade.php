<section class="c-hero-mini">
    <div class="bg">
      <span><img src="/vendor/vnedutech-cms/default/hocplus/frontend/images/bg-mini.png" alt=""></span>
    </div>
    <div class="centent">
      <div class="container inner">
        <h2 class="headline">Hợp tác giảng dạy cùng <span style="color: #fff000;">Học Plus</span></h2>
        <div class="text">Tham gia trải nghiệm hình thức giảng dạy mới thú vị và chia sẻ kiến thức của bạn đến hàng
          trăm ngàn học
          viên tại Học Plus</div>
        <a class="btn" data-scroll="#c-register-lecturers">Đăng ký giảng dạy</a>
      </div>
    </div>
  </section> <!-- / hero mini -->