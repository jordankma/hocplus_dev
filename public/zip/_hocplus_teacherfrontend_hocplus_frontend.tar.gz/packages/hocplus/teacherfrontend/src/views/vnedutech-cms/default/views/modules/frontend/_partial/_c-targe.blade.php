<section class="section c-target">
    <div class="container">
      <div class="headline">
        <h2 class="title">Ai nên đăng ký giảng dạy trên học plus</h2>
      </div>
      <div class="row group">
        <figure class="col-12 col-md-6 col-lg-3 item">
          <div class="inner">
            <div class="icon">
              <span><img src="images/icon/t1.png" alt=""></span>
            </div>
            <div class="info">
              <h3 class="title">Giáo viên</h3>
            </div>
          </div>
        </figure> <!-- / item -->
        <figure class="col-12 col-md-6 col-lg-3 item">
          <div class="inner">
            <div class="icon">
              <span><img src="images/icon/t2.png" alt=""></span>
            </div>
            <div class="info">
              <h3 class="title">Giảng viên đại học</h3>
            </div>
          </div>
        </figure> <!-- / item -->
        <figure class="col-12 col-md-6 col-lg-3 item">
          <div class="inner">
            <div class="icon">
              <span><img src="images/icon/t3.png" alt=""></span>
            </div>
            <div class="info">
              <h3 class="title">Chuyên gia</h3>
            </div>
          </div>
        </figure> <!-- / item -->
        <figure class="col-12 col-md-6 col-lg-3 item">
          <div class="inner">
            <div class="icon">
              <span><img src="images/icon/t4.png" alt=""></span>
            </div>
            <div class="info">
              <h3 class="title">Sinh viên sư phạm</h3>
            </div>
          </div>
        </figure> <!-- / item -->
      </div>
      <div class="bottom">
        <div class="inner">
          <b>“Có trên 3 năm kinh nghiệm trong môn học muốn giảng dạy Kỹ năng trình bày lưu loát, dễ hiểu, ngôn ngữ
            cơ thể tốt.”</b>
        </div>
      </div>
    </div>
  </section> <!-- / target -->